import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Crash_667b75bc8cac4b2504dca75189e19e603e0ee91e {
    static final String base64Bytes = String.join("", "rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAABdwQAAAABdADsCm4wMAbAgGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkY1VVVVVVVVVVVVVjY2NjY2NzY2N8Y2NjY2NjY2M1CgopCgZjY2NjY2NjBsCANAoKYwoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCksKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKdgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCmNjY2NjVVVVVVVVVVVVVWNjY2NjY3NjY2NjY2NjY2NjYzUKCikKBjAGwIA1CgopCil4");

    public static void main(String[] args) throws Throwable {
        ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(true);
        try {
            Method fuzzerInitialize = jazzer.JazzerTargetFindSalary.class.getMethod("fuzzerInitialize");
            fuzzerInitialize.invoke(null);
        } catch (NoSuchMethodException ignored) {
            try {
                Method fuzzerInitialize = jazzer.JazzerTargetFindSalary.class.getMethod("fuzzerInitialize", String[].class);
                fuzzerInitialize.invoke(null, (Object) args);
            } catch (NoSuchMethodException ignored1) {
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            System.exit(1);
        }
        com.code_intelligence.jazzer.api.CannedFuzzedDataProvider input = new com.code_intelligence.jazzer.api.CannedFuzzedDataProvider(base64Bytes);
        jazzer.JazzerTargetFindSalary.fuzzerTestOneInput(input);
    }
}
