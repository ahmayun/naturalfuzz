import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Crash_d281f0489f9afe93eb3c0b92b701d9ba9a86839d {
    static final String base64Bytes = String.join("", "rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAABdwQAAAABdAdQwIDAgMCAB8CAcX9/f39/eXd/f39/fywsLCwsLCwsLCxQU0hPVMCABSzAgAsKfxfAgMCAwIDAgCx/f39/LCwsLCwsLCwsLCx0cnVlBSx0cnVlBSwsNSxbLCwsLCwsLCwsLCwsLCwsLCwsLCwsCMCAwIAFLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsLCwswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCxqYXZhLiwsLCwsLCwsLCwsLSwsLCw1LFssLCwsLCwsLCwsLCwsLC1TTkFQU0hPVMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsNSxbLCwsLCwsLCwsLGphdmEuLCwsLCwsLCwsLCwIwIDAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCwsLCzAgAsKwIDAgMCAAsCAwIAsf39/fywsLCwsamF2YS4sLCwsLCwsLCwsLC0sLCwsNSxbLCwsLH9/f38sLCwsLCwsLCwsLHRydWUFLHRydWUFLCw1LFssLCwsLCwsLCwsLCwsLCwsLCwsLCwIwIDAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwtLCwsLGphdmEuLCwsLCwsLCwsLCwtLCwsLDUsWywsLCwsLCwsLCwsLCwsLVNOQVALCsCAwIABwIDAgMCAwIDAgCx/f39/LCxsLCwsLCwsLCwsCMCAwIAFLMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgCwsLCwsLCwsLAjAgMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCwsLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsamF2YS5TwIAESE9UwIAFLMCACwrAgMCAAcCAwIDAgMCAwIAsf39/fywsbCwsLCwsLCwsLAjAgMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCwsLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLGEsaix2YS4sLCwsLCwsLCwsLC0sLCwsNSxbLCwsLCwsLCwsLCwsLCwtU05BUFNIT1TAgAUswIALCsCAwIDAgAgQwIAsf39/fywsLCw1LFssLCwsLCwsLCwsamF2YS4swIDAgMCAwIDAgCx/f39/LCwsLCxqYXZhLiwsLCwsLCwsLCwsLSwsLCw1LFssLCwsLCwsLCwsLCwsLC1TTkFQU0hPVMCABSzAgAsKLCwsLCwsLCYsLCwsLCwsLCwsLCwsLVNOQVBTSE9UwIAFLMCACwrAgMCAAcCAwIDAgMCAwIAsf39/fywsbCwsLCwsLCwsLAjAgMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCwsLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsamF2YS4sLCwsLCwsLCwsLC0sLCwsNSxbLCwsLCwsLCwsLCwsLCwtU05BUFNIT1TAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLDUsWywsLCwsLCwsLCxqYXZhLiwsLCwsLCwsLCwsCMCAwIAFLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsLCwswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCwsLCwsLCwsLCwsLC1TTkFQU0hPVMCABSwgCwrAgMCAwIAIEMCALH9/f38sLCwsNSxbLCwsLCwsLCwsLGphdmEuLCwsLCwsLCwsLCwIwIDAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCwsLCzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLGphdmEuLCwsLCwsLCwsLCwtLCwsLDUsWywsLCwsLCwsLCwsLCwsLVNOQVBTSE9UwIAFLMCACwosLCwsLCwsJiwsLCwsLCwsLCwsLCwtU05BUFNIT1TAgAUswIALCsCAwIABwIDAgMCAwIDAgCx/f39/LCxsLCwsLCwsLCwsCMCAwIAFLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsLCwswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCxqYXZhLiwsLCwsLCwsLCwsLSwsLCw1LFssLCwsLCwsLCwsLCwsLC1TTkFQU0hPVMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsNSxbLCwsLCwsLCwsLGphdmEuLCwsLCwsLCwsLCwIwIDAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCwsLCzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLGphdmEuLCwsLCwsLCwsLCwtLCwsLDUsWywsLCwsLCwsLCwsLCwsLVNOQVBTSE9UwIAFLMCACwosLCwsLCwsJiwsLCxGLCwsPMCAwIAJBS0FeA==");

    public static void main(String[] args) throws Throwable {
        ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(true);
        try {
            Method fuzzerInitialize = jazzer.JazzerTargetDeliveryFaults.class.getMethod("fuzzerInitialize");
            fuzzerInitialize.invoke(null);
        } catch (NoSuchMethodException ignored) {
            try {
                Method fuzzerInitialize = jazzer.JazzerTargetDeliveryFaults.class.getMethod("fuzzerInitialize", String[].class);
                fuzzerInitialize.invoke(null, (Object) args);
            } catch (NoSuchMethodException ignored1) {
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            System.exit(1);
        }
        com.code_intelligence.jazzer.api.CannedFuzzedDataProvider input = new com.code_intelligence.jazzer.api.CannedFuzzedDataProvider(base64Bytes);
        jazzer.JazzerTargetDeliveryFaults.fuzzerTestOneInput(input);
    }
}
