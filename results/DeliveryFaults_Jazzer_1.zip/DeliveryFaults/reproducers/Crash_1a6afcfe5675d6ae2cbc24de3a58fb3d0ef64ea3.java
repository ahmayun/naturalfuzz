import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Crash_1a6afcfe5675d6ae2cbc24de3a58fb3d0ef64ea3 {
    static final String base64Bytes = String.join("", "rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAABdwQAAAABdAO9wIDAgMCAB8CAcX9/f39/wIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgHl3f39/f39BLCwsLCwsLCwsLFBTSE9UwIAFLMCACwp/F8CAwIDAgMCALH9/f38sLCwsLCwsLCwsLHRydWUFLHRydWUFLCw1LFssLCwsLCwsLCwsLCwsLCwsLCwsLCwIwIDAgAUswIALCsCAwIDAgAbAgMCALH9/f38sLCwsLCwsLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsamF2YS4sLCwsLCwsLCwsLC0sLCwsNSxbLCwsLCwsLCwsLCwsLCwtU05BUFNIT1TAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLDUsWywsLCwsLCwsLCxqYXZhLiwsLCwsLCwsLCwsCMCAwIAFLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsLCwswIALCsCAwIDAgALAgMCALH9/f38sLCwsLGphdmEuLCwsLCwsLCwsLCwtLCwsLDUsWywsLCwsLCwsLCwsLCwsLVNOQVBTSE9UwIAFLMCACwrAgMCAAcCAwIDAgMCAwIAsf39/fywsbCwsLCwsLCwsLAjAgMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCwsLMCACwrAgMCAwIDAgMCAwIAsf39/f34sLGEsaix2YS4sLCwsLCwsLCwsLC0sLCwsNSxbLCwsLCwsLCwsLCwsLCwtU05BUFNIT1TAgAUswIALCsCAwIDAgAgQwIAsf39/fywsLCw1LFssLCwsLCwsLCwsamF2YS4sLCwsLCwsLCwsLAjAgMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCwsLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsamF2YS4sLCwsLCwsLCwsLC0sLCwsNSwGwIDAgMCAWywsLCwsLCwsLCwsLCwsLVNOQVBTSE9UwIAFLMCACwosLCwsLCwsJiwsLCxGLCwsPMCAwIAJBS0FeA==");

    public static void main(String[] args) throws Throwable {
        ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(true);
        try {
            Method fuzzerInitialize = jazzer.JazzerTargetDeliveryFaults.class.getMethod("fuzzerInitialize");
            fuzzerInitialize.invoke(null);
        } catch (NoSuchMethodException ignored) {
            try {
                Method fuzzerInitialize = jazzer.JazzerTargetDeliveryFaults.class.getMethod("fuzzerInitialize", String[].class);
                fuzzerInitialize.invoke(null, (Object) args);
            } catch (NoSuchMethodException ignored1) {
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            System.exit(1);
        }
        com.code_intelligence.jazzer.api.CannedFuzzedDataProvider input = new com.code_intelligence.jazzer.api.CannedFuzzedDataProvider(base64Bytes);
        jazzer.JazzerTargetDeliveryFaults.fuzzerTestOneInput(input);
    }
}
