import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Crash_3131832d5f43c1203a685146759ed0edadbbddd0 {
    static final String base64Bytes = String.join("", "rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAABdwQAAAABdAG3wIDAgMCAB8CAcX9/f39/eXd/f39/fywsLCwsLCwsLCxQU0hPVMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCwsLCwsLHRydWUFLHRydWUFLCw1LFssLCwsLCwsLCwsLCwsLCwsLCwsLCwIwIDAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCwsLCzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLGphdmEuLCwsLCwsLCwsLCwtLCwsLDUsWywsLCwsLCwsLCwsLCwsLVNOQVBTSE9UwIAFLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCw1LFssLCwsLCwsLCwsLCwsLCwsLCwsLCwIwIDAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCwsLCzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLGphdmEuLCwsLCwsLCwsLCwtLCwsLDUsWywsLCwsLCwsLCwsLCwsLVNOQVBTSE9UwIAFLMCACwrAgMCAwIDAgMCAwIAsf39/fywsLCwsLCwsLCwsLCwsLCwsLCwsRiwsLDzAgMCACQUtBXg=");

    public static void main(String[] args) throws Throwable {
        ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(true);
        try {
            Method fuzzerInitialize = jazzer.JazzerTargetDeliveryFaults.class.getMethod("fuzzerInitialize");
            fuzzerInitialize.invoke(null);
        } catch (NoSuchMethodException ignored) {
            try {
                Method fuzzerInitialize = jazzer.JazzerTargetDeliveryFaults.class.getMethod("fuzzerInitialize", String[].class);
                fuzzerInitialize.invoke(null, (Object) args);
            } catch (NoSuchMethodException ignored1) {
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            System.exit(1);
        }
        com.code_intelligence.jazzer.api.CannedFuzzedDataProvider input = new com.code_intelligence.jazzer.api.CannedFuzzedDataProvider(base64Bytes);
        jazzer.JazzerTargetDeliveryFaults.fuzzerTestOneInput(input);
    }
}
