import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Crash_1132f63026218043d5696afcab4695a37deb62e0 {
    static final String base64Bytes = String.join("", "rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAABdwQAAAABdAFZwIDAgMCAB8CAfywsLCwsLCwsLCwsLCwsdHJ1ZQUsLDUsWywsLCwsLCwsLCwsLCwsLCwsLCwsLAjAgMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLMCABSwsLCzAgATAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCwsLCx/f39/eXd/f39/fywsLCwsLCwsLCwsLCwsdHJ1ZQUsLDUsWywsLCwsLCwsLCwsLCwsLCwsLCwsLAjAgMCABSzAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCzAgATAgAsKwIDAgMCAwIDAgMCALH9/f38sLCwsLCwsLCwsLCwsLCxgLCwsLCw1LFssLCwsLCwsLCwsLCwsLCwsLCwsLCwIwIDAgAUswIALCsCAwIDAgMCAwIDAgCx/f39/LCwsLCwsLCwsLCwsLCwsLCwsLCxGLCwsPMCAwIAJBS0FeA==");

    public static void main(String[] args) throws Throwable {
        ClassLoader.getSystemClassLoader().setDefaultAssertionStatus(true);
        try {
            Method fuzzerInitialize = jazzer.JazzerTargetDeliveryFaults.class.getMethod("fuzzerInitialize");
            fuzzerInitialize.invoke(null);
        } catch (NoSuchMethodException ignored) {
            try {
                Method fuzzerInitialize = jazzer.JazzerTargetDeliveryFaults.class.getMethod("fuzzerInitialize", String[].class);
                fuzzerInitialize.invoke(null, (Object) args);
            } catch (NoSuchMethodException ignored1) {
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            System.exit(1);
        }
        com.code_intelligence.jazzer.api.CannedFuzzedDataProvider input = new com.code_intelligence.jazzer.api.CannedFuzzedDataProvider(base64Bytes);
        jazzer.JazzerTargetDeliveryFaults.fuzzerTestOneInput(input);
    }
}
