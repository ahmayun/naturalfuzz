import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Crash_5914fd8e3768ec6685104e820eeac47b74e85cf7 {
    static final String base64Bytes = String.join("", "rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAACdwQAAAACdAFvwIDAgMCAwIDAgFRUVFRUVFRUVFRUVFRUVFRUVCwtVMCAwIDAgFRUVFRUVFRUVFRUVFRUVFRUVCwtVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFQCwIDAgA/AgHZuVFRUVFRUVFRUVMCAwIDAgFRUVFRUVFRUVFRUVFRUVFRUVCwqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiotVMCAwIDAgFRUVFRUVFRUVFRUVFRUVFRUVCwtVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFQCwIDAgA/AgHZuVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVALAgMCAD8CAVFRUVFRUVFRUVFRUVFRUVFRUAsCAwIAPwIB2bnQAAHg=");

    public static void main(String[] args) throws Throwable {
        Crash_5914fd8e3768ec6685104e820eeac47b74e85cf7.class.getClassLoader().setDefaultAssertionStatus(true);
        try {
            Method fuzzerInitialize = jazzer.JazzerTargetCommuteTypeFull.class.getMethod("fuzzerInitialize");
            fuzzerInitialize.invoke(null);
        } catch (NoSuchMethodException ignored) {
            try {
                Method fuzzerInitialize = jazzer.JazzerTargetCommuteTypeFull.class.getMethod("fuzzerInitialize", String[].class);
                fuzzerInitialize.invoke(null, (Object) args);
            } catch (NoSuchMethodException ignored1) {
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            System.exit(1);
        }
        com.code_intelligence.jazzer.api.CannedFuzzedDataProvider input = new com.code_intelligence.jazzer.api.CannedFuzzedDataProvider(base64Bytes);
        jazzer.JazzerTargetCommuteTypeFull.fuzzerTestOneInput(input);
    }
}